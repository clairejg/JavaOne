//Car
//Claire Choo
//05/24/2019
public class Car extends Vehicle
{	
	public Car(int numWheel, int mpg) 
	{
	super(4, mpg);
	}
	@Override
	public void display() 
	{
		super.display();
	}
	
}
