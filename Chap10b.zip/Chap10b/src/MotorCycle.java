//MotorCycle
//Claire Choo
//05/24/2019
public class MotorCycle extends Vehicle
{	
	public MotorCycle(int numWheel, int mpg) 
	{
		super(2, mpg);
	}
	@Override
	public void display() 
	{
		super.display();
	}
	
}