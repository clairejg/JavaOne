//TestScores.java
//Chinkyung Choo
//03/21/2019

public class TestScores
{

	public static void main(String[] args) 
	{
		Student first = new Student("FC123",100,80,94);
		first.displayInfo();
		Student second = new Student("FC456",78,92,80);
		second.displayInfo();

	}

}
